#!/bin/bash

check_result() {
	grep -q root tmp
	if [ $? -eq 0 ]; then
		echo "$1 passed"
	else
		echo -e "\033[31m$1 failed\033[0m"
	fi	
}

for student in */; do
	student=${student%/}

	cd $student
	
	echo "start testing $student submissions..."
	
	if [ -f "bof1.py" ]; then
		echo "whoami;exit" | nc -nv -l 9090 > tmp 2>/dev/null &
		python3 bof1.py $1 $2 > /dev/null
		cat badfile | nc 10.9.0.5 9090
		sleep 0.2
		kill $! 2>/dev/null
		check_result "bof1"
	else
		echo -e "\033[31mbof1 not exist\033[0m"
	fi
	
	if [ -f "bof2.py" ]; then
		echo "whoami;exit" | nc -nv -l 9090 > tmp 2>/dev/null &
		python3 bof2.py $3 > /dev/null
		cat badfile | nc 10.9.0.6 9090
		sleep 0.2
		kill $! 2>/dev/null
		check_result "bof2"
	else
		echo -e "\033[31mbof2 not exist\033[0m"
	fi
	
	if [ -f "bof3.py" ]; then
		echo "whoami;exit" | nc -nv -l 9090 > tmp 2>/dev/null &
		python3 bof3.py $4 $5 > /dev/null
		cat badfile | nc 10.9.0.7 9090
		sleep 0.2
		kill $! 2>/dev/null
		check_result "bof3"
	else
		echo -e "\033[31mbof3 not exist\033[0m"
	fi
	
	cd ..
done

