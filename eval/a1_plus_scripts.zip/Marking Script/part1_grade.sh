#!/bin/bash

for student in */; do
	student=${student%/}

	cd $student
	
	sudo touch /etc/important /etc/zzz
	
	echo "start testing $student submissions..."
	
	if [ -f "catall.sh" ]; then
		grep -q su "catall.sh"
		if [ $? -eq 0 ]; then
			echo -e "\033[31mcatall.sh contains a sudo command\033[0m"
		else
			./catall.sh
			ls /etc | grep -q important
			if [ $? -eq 0 ]; then
				echo -e "\033[31mcatall failed\033[0m"
			else
				echo "catall passed"
			fi
		fi
	else
		echo -e "\033[31mcatall.sh not exist\033[0m"
	fi
	
	
	if [ -f "cap_leak.sh" ]; then
		grep -q su "cap_leak.sh"
		if [ $? -eq 0 ]; then
			echo -e "\033[31mcap_leak.sh contains a sudo command\033[0m"
		else
			./cap_leak.sh > /dev/null
			cat /etc/zzz | grep -q "secret message"
			if [ $? -eq 0 ]; then
				echo "cap_leak passed"
			else
				echo -e "\033[31mcap_leak failed\033[0m"
			fi
		fi
	else
		echo -e "\033[31mcap_leak.sh not exist\033[0m"
	fi
	
	
	sudo rm -f /etc/important /etc/zzz 2>/dev/null
	cd ..
done

