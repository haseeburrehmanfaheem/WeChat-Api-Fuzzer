#!/bin/bash

check_result() {
	grep -q root tmp
	if [ $? -eq 0 ]; then
		echo "$1 passed"
	else
		echo -e "\033[31m$1 failed\033[0m"
	fi	
}

for student in */; do
	student=${student%/}

	cd $student
	
	echo "start testing $student submissions..."
	
	if [ -f "fmt1.py" ]; then
		python3 fmt1.py $1 > /dev/null 2>/dev/null
		cat badfile | nc 10.9.0.5 9090
		sleep 0.2
		tail -n 3 /home/seed/Desktop/part-4/tmp | grep -q "The target variable's value (after):  0x00004000"
		if [ $? -eq 0 ]; then
			echo "fmt1 passed" 
		else
			echo -e "\033[31mfmt1 failed\033[0m"
		fi
	else
		echo -e "\033[31mfmt1 not exist\033[0m"
	fi
	
	if [ -f "fmt2.py" ]; then
		echo "whoami;exit" | nc -nv -l 9090 > tmp 2>/dev/null &
		python3 fmt2.py $2 $3 > /dev/null 2>/dev/null
		cat badfile | nc 10.9.0.6 9090
		sleep 0.2
		kill $! 2>/dev/null
		check_result "fmt2"
	else
		echo -e "\033[31mfmt2 not exist\033[0m"
	fi
	
	cd ..
done

