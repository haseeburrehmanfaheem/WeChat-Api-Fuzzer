import os

files = os.listdir()

student_list = set()

for file in files:
	student_name = file.split()[3] + file.split()[2]
	if student_name not in student_list:
		student_list.add(student_name)
		os.mkdir(student_name)
	os.rename(file, student_name+'/'+file)


# print(student_list)
# print('Total students: ', len(student_list))
