#!/bin/bash


files=("catall.sh" "cap_leak.sh" "target_process.sh" "rc_attack.c" "bof1.py" "bof2.py" "bof3.py" "fmt1.py" "fmt2.py")

for dir in */; do
  dir=${dir%/}
  
  #chmod u+x $dir/catall.sh $dir/cap_leak.sh $dir/target_process.sh 2>/dev/null
  
  #cp /home/seed/Desktop/part-1/catall $dir
  #cp /home/seed/Desktop/part-1/cap_leak $dir
  #sudo chown root $dir/catall $dir/cap_leak
  #sudo chmod 4755 $dir/catall $dir/cap_leak
  
  #cp /home/seed/Desktop/part-2/vulp $dir
  #sudo chown root $dir/vulp
  #sudo chmod 4755 $dir/vulp
  echo $dir
  gcc $dir/rc_attack.c -o $dir/a.out
  
  missing_files=()

  for file in "${files[@]}"; do
    if [ ! -f "$dir/$file" ]; then
      missing_files+=("$file")
    fi
  done

  if [ ${#missing_files[@]} -gt 0 ]; then
    echo "$dir missing some files:"
    for file in "${missing_files[@]}"; do
      echo -e "\033[31m${file}\033[0m"
    done
  else
    :
  fi
done
