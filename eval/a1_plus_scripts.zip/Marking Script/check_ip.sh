#!/bin/bash


files=("bof1.py" "bof2.py" "bof3.py" "fmt2.py")

for dir in */; do
  dir=${dir%/}
  
  invalid_files=()

  for file in "${files[@]}"; do
    if [ -f "$dir/$file" ]; then
      grep -q "10.0.2.5" "$dir/$file"
      if [ $? -ne 0 ]; then
        invalid_files+=("$file")
      fi
    fi
  done

  if [ ${#invalid_files[@]} -gt 0 ]; then
    echo "$dir has some invalid files:"
    for file in "${invalid_files[@]}"; do
      echo "$file"
    done
  else
    :
  fi
done
